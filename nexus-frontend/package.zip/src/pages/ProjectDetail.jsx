import React, { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { ArrowLeft, Plus, Upload, FileText, MessageSquare, Users, Calendar, DollarSign, TrendingUp, Edit2, Trash2, X, Save, Building2 } from 'lucide-react'
import { projectsApi, authApi, clientsApi, resourcesApi } from '@/api/index.js'
import { Btn, Badge, ProgressBar, Tabs, Modal, Input, Textarea, Spinner, Avatar } from '@/components/ui/index.jsx'
import { STATUS_COLOR, STATUS_LABEL, PRIORITY_COLOR, PRIORITY_LABEL, formatDate, formatCurrency, formatBytes, timeAgo, extractError } from '@/utils/index.js'
import { useAuthStore } from '@/stores/authStore.js'

const TABS = [
  { id: 'overview',   label: 'Overview' },
  { id: 'updates',    label: 'Updates',   icon: MessageSquare },
  { id: 'documents',  label: 'Documents', icon: FileText },
  { id: 'team',       label: 'Team',      icon: Users },
]

const sel = { width: '100%', background: 'var(--bg-2)', border: '1px solid var(--border)', borderRadius: 'var(--r-md)', color: 'var(--text-1)', fontSize: '13px', padding: '8px 12px', outline: 'none' }

export default function ProjectDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const qc = useQueryClient()
  const [tab, setTab] = useState('overview')
  const [showUpdate, setShowUpdate] = useState(false)
  const [editing, setEditing] = useState(false)
  const [showDelete, setShowDelete] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState(null)

  const user = useAuthStore(s => s.user)
  const canEdit = user?.role === 'admin' || user?.role === 'manager'

  const { data: project, isLoading } = useQuery({
    queryKey: ['project', id],
    queryFn: () => projectsApi.get(id).then(r => r.data),
  })

  // For edit dropdowns
  const { data: clients } = useQuery({
    queryKey: ['clients-all'],
    queryFn: () => clientsApi.list({ page_size: 200 }).then(r => r.data.results || r.data),
    enabled: editing,
  })
  const { data: managers } = useQuery({
    queryKey: ['managers-list'],
    queryFn: () => authApi.users({ page_size: 200, role: 'manager' }).then(r => r.data.results || r.data),
    enabled: editing,
  })
  const { data: adminsList } = useQuery({
    queryKey: ['admins-list'],
    queryFn: () => authApi.users({ page_size: 200, role: 'admin' }).then(r => r.data.results || r.data),
    enabled: editing,
  })

  function startEdit() {
    const p = project
    setForm({
      name:        p.name || '',
      description: p.description || '',
      client:      p.client || '',
      manager:     p.manager || '',
      status:      p.status || 'planning',
      priority:    p.priority || 'medium',
      start_date:  p.start_date || '',
      end_date:    p.end_date || '',
      budget:      p.budget || '',
    })
    setEditing(true)
    setError('')
  }

  async function saveEdit() {
    setSaving(true)
    setError('')
    try {
      const payload = { ...form, budget: form.budget ? parseFloat(form.budget) : 0 }
      if (!payload.client) delete payload.client
      if (!payload.manager) delete payload.manager
      await projectsApi.update(id, payload)
      await qc.invalidateQueries(['project', id])
      await qc.invalidateQueries(['projects'])
      setEditing(false)
      setForm(null)
    } catch (err) {
      setError(extractError(err))
    } finally {
      setSaving(false)
    }
  }

  async function deleteProject() {
    try {
      await projectsApi.delete(id)
      qc.invalidateQueries(['projects'])
      navigate('/projects')
    } catch (err) {
      setError(extractError(err))
    }
  }

  const f = (k, v) => setForm(p => ({ ...p, [k]: v }))

  if (isLoading) return (
    <div style={{ display: 'flex', justifyContent: 'center', padding: 'var(--sp-16)' }}>
      <Spinner size={32} />
    </div>
  )
  if (!project) return <div style={{ color: 'var(--text-2)' }}>Project not found.</div>

  const p = project
  const managerOptions = [...(adminsList || []), ...(managers || [])]

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-6)' }}>

      {/* Back */}
      <button onClick={() => navigate('/projects')}
        style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--text-3)', background: 'none', border: 'none', cursor: 'pointer', fontSize: '13px', width: 'fit-content' }}>
        <ArrowLeft size={14} /> Back to Projects
      </button>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 'var(--sp-4)' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-3)', marginBottom: 6 }}>
            <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.8rem', letterSpacing: '-0.02em' }}>{p.name}</h1>
            <Badge color={STATUS_COLOR[p.status]}>{STATUS_LABEL[p.status]}</Badge>
            <Badge color={PRIORITY_COLOR[p.priority]}>{PRIORITY_LABEL[p.priority]}</Badge>
          </div>
          <div style={{ color: 'var(--text-2)', fontSize: '14px', display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
            {p.client_detail?.name
              ? <><Building2 size={12} /><span style={{ color: 'var(--accent)' }}>{p.client_detail.name}</span> · </>
              : <span style={{ color: 'var(--text-3)' }}>No client · </span>
            }
            Managed by {p.manager_detail?.name || <span style={{ color: 'var(--danger)', fontSize: '12px' }}>⚠ No manager assigned</span>}
          </div>
        </div>

        {canEdit && !editing && (
          <div style={{ display: 'flex', gap: 'var(--sp-2)' }}>
            <Btn variant="ghost" size="sm" onClick={() => setShowUpdate(true)} icon={<Plus size={14} />}>Add Update</Btn>
            <Btn variant="ghost" size="sm" onClick={startEdit} icon={<Edit2 size={14} />}>Edit</Btn>
            <Btn variant="ghost" size="sm" onClick={() => setShowDelete(true)}
              style={{ color: 'var(--danger)', borderColor: 'var(--danger)' }}
              icon={<Trash2 size={14} />}>Delete</Btn>
          </div>
        )}
        {canEdit && editing && (
          <div style={{ display: 'flex', gap: 'var(--sp-2)' }}>
            <Btn variant="ghost" size="sm" onClick={() => { setEditing(false); setForm(null) }} icon={<X size={14} />}>Cancel</Btn>
            <Btn size="sm" loading={saving} onClick={saveEdit} icon={<Save size={14} />}>Save Changes</Btn>
          </div>
        )}
      </div>

      {error && <div style={{ color: 'var(--danger)', fontSize: '13px', background: 'rgba(248,113,113,0.1)', padding: '10px 14px', borderRadius: 'var(--r-md)' }}>{error}</div>}

      {/* Edit Form */}
      {editing && form && (
        <div style={{ background: 'var(--bg-1)', border: '1px solid var(--accent)', borderRadius: 'var(--r-lg)', padding: 'var(--sp-5)', display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)' }}>
          <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Editing Project</div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--sp-4)' }}>
            <Input label="Project Name" value={form.name} onChange={e => f('name', e.target.value)} required />
            <div>
              <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-2)', marginBottom: 6 }}>Client</div>
              <select value={form.client} onChange={e => f('client', e.target.value)} style={sel}>
                <option value="">No client</option>
                {(clients || []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--sp-4)' }}>
            <div>
              <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-2)', marginBottom: 6 }}>Status</div>
              <select value={form.status} onChange={e => f('status', e.target.value)} style={sel}>
                <option value="planning">Planning</option>
                <option value="in_progress">In Progress</option>
                <option value="review">Review</option>
                <option value="completed">Completed</option>
                <option value="on_hold">On Hold</option>
              </select>
            </div>
            <div>
              <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-2)', marginBottom: 6 }}>Priority</div>
              <select value={form.priority} onChange={e => f('priority', e.target.value)} style={sel}>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="critical">Critical</option>
              </select>
            </div>
          </div>

          <div>
            <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-2)', marginBottom: 6 }}>Manager</div>
            <select value={form.manager} onChange={e => f('manager', e.target.value)} style={sel}>
              <option value="">No manager</option>
              {managerOptions.map(u => <option key={u.id} value={u.id}>{u.name} ({u.role})</option>)}
            </select>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--sp-4)' }}>
            <Input label="Start Date" type="date" value={form.start_date} onChange={e => f('start_date', e.target.value)} />
            <Input label="End Date" type="date" value={form.end_date} onChange={e => f('end_date', e.target.value)} />
          </div>

          <Input label="Budget (USD)" type="number" min="0" value={form.budget} onChange={e => f('budget', e.target.value)} />
          <Textarea label="Description" value={form.description} onChange={e => f('description', e.target.value)} placeholder="Project overview…" />
        </div>
      )}

      {/* Metric Boxes */}
      {!editing && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 'var(--sp-4)' }}>
          <MetricBox icon={Calendar}    label="Start"    value={formatDate(p.start_date)} />
          <MetricBox icon={Calendar}    label="End"      value={formatDate(p.end_date)} />
          <MetricBox icon={DollarSign}  label="Budget"   value={formatCurrency(p.budget)} />
          <MetricBox icon={DollarSign}  label="Spent"    value={formatCurrency(p.spent)} accent={p.is_over_budget ? 'var(--danger)' : undefined} />
          <MetricBox icon={TrendingUp}  label="Progress" value={`${p.progress}%`} />
          <MetricBox icon={Users}       label="Team"     value={p.resource_details?.length || p.resources?.length || 0} />
        </div>
      )}

      {/* Progress bar */}
      {!editing && (
        <div style={{ background: 'var(--bg-1)', border: '1px solid var(--border)', borderRadius: 'var(--r-lg)', padding: 'var(--sp-5)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 'var(--sp-3)' }}>
            <span style={{ fontWeight: 600, fontSize: '13px' }}>Overall Progress</span>
            <span style={{ fontSize: '13px', fontFamily: 'var(--font-mono)', color: 'var(--text-2)' }}>{p.progress}%</span>
          </div>
          <ProgressBar value={p.progress} height={8} />
        </div>
      )}

      {/* Tabs */}
      <div style={{ background: 'var(--bg-1)', border: '1px solid var(--border)', borderRadius: 'var(--r-lg)', overflow: 'hidden' }}>
        <div style={{ padding: 'var(--sp-4) var(--sp-5) 0', borderBottom: '1px solid var(--border)' }}>
          <Tabs
            tabs={TABS.map(t => ({ ...t, count: t.id === 'updates' ? p.updates?.length : t.id === 'documents' ? p.documents?.length : undefined }))}
            active={tab} onChange={setTab}
          />
        </div>
        <div style={{ padding: 'var(--sp-6)' }}>
          {tab === 'overview'  && <OverviewTab project={p} />}
          {tab === 'updates'   && <UpdatesTab updates={p.updates || []} />}
          {tab === 'documents' && <DocumentsTab documents={p.documents || []} projectId={p.id} canEdit={canEdit} onRefresh={() => qc.invalidateQueries(['project', id])} />}
          {tab === 'team'      && <TeamTab resources={p.resource_details || []} manager={p.manager_detail} projectId={p.id} canEdit={canEdit} onRefresh={() => qc.invalidateQueries(['project', id])} />}
        </div>
      </div>

      {/* Delete Confirm */}
      {showDelete && (
        <Modal open onClose={() => setShowDelete(false)} title="Delete Project" width={420}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-5)' }}>
            <p style={{ color: 'var(--text-2)', fontSize: '14px' }}>
              Are you sure you want to delete <strong style={{ color: 'var(--text-0)' }}>{p.name}</strong>? This cannot be undone.
            </p>
            <div style={{ display: 'flex', gap: 'var(--sp-3)', justifyContent: 'flex-end' }}>
              <Btn variant="ghost" onClick={() => setShowDelete(false)}>Cancel</Btn>
              <Btn onClick={deleteProject} style={{ background: 'var(--danger)', borderColor: 'var(--danger)' }}>Delete Project</Btn>
            </div>
          </div>
        </Modal>
      )}

      {showUpdate && (
        <AddUpdateModal projectId={p.id} onClose={() => setShowUpdate(false)} onDone={() => { setShowUpdate(false); qc.invalidateQueries(['project', id]) }} />
      )}
    </div>
  )
}

/* ── Sub-components ─────────────────────────────────────── */

function MetricBox({ icon: Icon, label, value, accent }) {
  return (
    <div style={{ background: 'var(--bg-1)', border: '1px solid var(--border)', borderRadius: 'var(--r-lg)', padding: 'var(--sp-4)', display: 'flex', flexDirection: 'column', gap: 4 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <Icon size={12} color="var(--text-3)" />
        <span style={{ fontSize: '11px', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>{label}</span>
      </div>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '15px', fontWeight: 600, color: accent || 'var(--text-0)' }}>{value || '—'}</div>
    </div>
  )
}

function OverviewTab({ project: p }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-5)' }}>
      {p.description && (
        <div>
          <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 'var(--sp-2)' }}>Description</div>
          <p style={{ fontSize: '14px', color: 'var(--text-1)', lineHeight: 1.7 }}>{p.description}</p>
        </div>
      )}
      {p.client_detail && (
        <div>
          <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 'var(--sp-2)' }}>Client</div>
          <div style={{ fontSize: '14px', color: 'var(--accent)', fontWeight: 600 }}>{p.client_detail.name}</div>
          {p.client_detail.email && <div style={{ fontSize: '12px', color: 'var(--text-3)' }}>{p.client_detail.email}</div>}
        </div>
      )}
      {p.tags?.length > 0 && (
        <div>
          <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 'var(--sp-2)' }}>Tags</div>
          <div style={{ display: 'flex', gap: 'var(--sp-2)', flexWrap: 'wrap' }}>
            {p.tags.map(tag => (
              <span key={tag} style={{ background: 'var(--bg-3)', border: '1px solid var(--border)', borderRadius: 'var(--r-full)', padding: '3px 10px', fontSize: '12px', color: 'var(--text-2)' }}>{tag}</span>
            ))}
          </div>
        </div>
      )}
      {!p.description && !p.client_detail && !p.tags?.length && (
        <p style={{ color: 'var(--text-3)', fontSize: '14px' }}>No additional details.</p>
      )}
    </div>
  )
}

function UpdatesTab({ updates }) {
  if (!updates.length) return <p style={{ color: 'var(--text-3)', fontSize: '14px' }}>No updates yet.</p>
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)' }}>
      {updates.map(u => (
        <div key={u.id} style={{ display: 'flex', gap: 'var(--sp-4)' }}>
          <Avatar name={u.author?.name} size={32} />
          <div style={{ flex: 1, background: 'var(--bg-2)', borderRadius: 'var(--r-md)', padding: 'var(--sp-4)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 'var(--sp-2)' }}>
              <span style={{ fontWeight: 600, fontSize: '13px' }}>{u.author?.name || 'Unknown'}</span>
              <span style={{ fontSize: '11px', color: 'var(--text-3)', fontFamily: 'var(--font-mono)' }}>{timeAgo(u.created_at)}</span>
            </div>
            <p style={{ fontSize: '13px', color: 'var(--text-1)', lineHeight: 1.6 }}>{u.content}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

function DocumentsTab({ documents, projectId, canEdit, onRefresh }) {
  const [uploading, setUploading] = useState(false)
  async function handleUpload(e) {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    const form = new FormData()
    form.append('file', file)
    form.append('name', file.name)
    try { await projectsApi.uploadDocument(projectId, form); onRefresh() } catch {}
    setUploading(false)
  }
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)' }}>
      {canEdit && (
        <label style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'var(--bg-3)', border: '1px solid var(--border)', borderRadius: 'var(--r-md)', padding: '7px 14px', fontSize: '13px', fontWeight: 600, color: 'var(--text-1)', cursor: 'pointer' }}>
          {uploading ? <Spinner size={14} /> : <Upload size={14} />} Upload document
          <input type="file" hidden onChange={handleUpload} />
        </label>
      )}
      {documents.length === 0 ? (
        <p style={{ color: 'var(--text-3)', fontSize: '14px' }}>No documents uploaded.</p>
      ) : documents.map(doc => (
        <div key={doc.id} style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-3)', padding: 'var(--sp-3) var(--sp-4)', background: 'var(--bg-2)', borderRadius: 'var(--r-md)', border: '1px solid var(--border)' }}>
          <FileText size={16} color="var(--text-3)" />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: '13px', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{doc.name}</div>
            <div style={{ fontSize: '11px', color: 'var(--text-3)' }}>{formatBytes(doc.file_size)} · {timeAgo(doc.uploaded_at)}</div>
          </div>
          {doc.file && <a href={doc.file} target="_blank" rel="noopener noreferrer" style={{ fontSize: '12px', color: 'var(--accent)', textDecoration: 'none' }}>Download</a>}
        </div>
      ))}
    </div>
  )
}

function TeamTab({ resources, manager, projectId, canEdit, onRefresh }) {
  const [showAssign, setShowAssign] = useState(false)
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)' }}>
      {manager && (
        <div>
          <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 'var(--sp-3)' }}>Project Manager</div>
          <TeamMemberRow user={manager} />
        </div>
      )}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--sp-3)' }}>
          <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Resources ({resources.length})</div>
          {canEdit && <Btn size="sm" variant="secondary" icon={<Plus size={12} />} onClick={() => setShowAssign(true)}>Assign</Btn>}
        </div>
        {resources.length === 0
          ? <p style={{ color: 'var(--text-3)', fontSize: '13px' }}>No resources assigned.</p>
          : resources.map(r => <TeamMemberRow key={r.id} user={r} projectId={canEdit ? projectId : null} onRemove={canEdit ? onRefresh : null} />)
        }
      </div>
      {showAssign && <AssignResourceModal projectId={projectId} assignedIds={resources.map(r => r.id)} onClose={() => setShowAssign(false)} onDone={() => { setShowAssign(false); onRefresh() }} />}
    </div>
  )
}

function TeamMemberRow({ user, projectId, onRemove }) {
  const [removing, setRemoving] = useState(false)
  async function handleRemove() {
    if (!projectId || !onRemove) return
    setRemoving(true)
    try { await projectsApi.removeResource(projectId, user.id); onRemove() } finally { setRemoving(false) }
  }
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-3)', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
      <Avatar name={user.name} src={user.avatar} size={36} role={user.role} />
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 600, fontSize: '13px', color: 'var(--text-0)' }}>{user.name || '—'}</div>
        <div style={{ fontSize: '11px', color: 'var(--text-3)', textTransform: 'capitalize' }}>{user.role || 'Member'}{user.department ? ` · ${user.department}` : ''}</div>
      </div>
      {projectId && onRemove && (
        <button onClick={handleRemove} disabled={removing}
          style={{ background: 'none', border: '1px solid var(--border)', borderRadius: 'var(--r-sm)', cursor: 'pointer', padding: '3px 8px', fontSize: '11px', color: 'var(--text-3)', transition: 'all var(--t-fast)' }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--danger)'; e.currentTarget.style.color = 'var(--danger)' }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.color = 'var(--text-3)' }}>
          {removing ? '…' : 'Remove'}
        </button>
      )}
    </div>
  )
}

function AssignResourceModal({ projectId, assignedIds, onClose, onDone }) {
  const [loading, setLoading] = useState(false)
  const { data } = useQuery({
    queryKey: ['resources-assign'],
    queryFn: () => resourcesApi.list({ page_size: 200 }).then(r => r.data.results || r.data),
  })
  const available = (data || []).filter(r => r.user_detail?.is_active && !assignedIds.includes(r.user_detail?.id))

  async function assign(userId) {
    setLoading(true)
    try { await projectsApi.assignResource(projectId, userId); onDone() } finally { setLoading(false) }
  }

  return (
    <Modal open onClose={onClose} title="Assign Resource" width={420}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-3)' }}>
        {available.length === 0
          ? <div style={{ color: 'var(--text-3)', fontSize: '13px', textAlign: 'center', padding: 'var(--sp-6)' }}>All resources already assigned</div>
          : available.map(r => (
            <div key={r.id} style={{ display: 'flex', alignItems: 'center', gap: 'var(--sp-3)', padding: 'var(--sp-3)', borderRadius: 'var(--r-md)', border: '1px solid var(--border)', background: 'var(--bg-2)' }}>
              <Avatar name={r.user_detail?.name} size={34} role="resource" />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: '13px' }}>{r.user_detail?.name}</div>
                <div style={{ fontSize: '11px', color: 'var(--text-3)' }}>{r.job_title || 'No title'}</div>
              </div>
              <Btn size="sm" loading={loading} onClick={() => assign(r.user_detail?.id)}>Assign</Btn>
            </div>
          ))
        }
      </div>
    </Modal>
  )
}

function AddUpdateModal({ projectId, onClose, onDone }) {
  const [content, setContent] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  async function submit(e) {
    e.preventDefault()
    if (!content.trim()) return
    setLoading(true)
    try { await projectsApi.addUpdate(projectId, { content }); onDone() }
    catch (err) { setError(extractError(err)) }
    finally { setLoading(false) }
  }
  return (
    <Modal open onClose={onClose} title="Add Project Update">
      <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-4)' }}>
        {error && <div style={{ color: 'var(--danger)', fontSize: '13px' }}>{error}</div>}
        <Textarea label="Update" value={content} onChange={e => setContent(e.target.value)} placeholder="What's the latest on this project?" style={{ minHeight: 120 }} required />
        <div style={{ display: 'flex', gap: 'var(--sp-3)', justifyContent: 'flex-end' }}>
          <Btn variant="ghost" type="button" onClick={onClose}>Cancel</Btn>
          <Btn type="submit" loading={loading}>Post Update</Btn>
        </div>
      </form>
    </Modal>
  )
}
