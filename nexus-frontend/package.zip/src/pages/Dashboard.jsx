import React from 'react'
import { useQuery } from '@tanstack/react-query'
import { FolderKanban, Building2, Users, TrendingUp, Clock, CheckCircle2, AlertTriangle } from 'lucide-react'
import { projectsApi, clientsApi, resourcesApi } from '@/api/index.js'
import { StatCard, ProgressBar, Badge, Skeleton } from '@/components/ui/index.jsx'
import { STATUS_COLOR, STATUS_LABEL, PRIORITY_COLOR, formatDate, timeAgo } from '@/utils/index.js'
import { useAuthStore } from '@/stores/authStore.js'
import { useNavigate } from 'react-router-dom'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  PieChart, Pie, Cell, ResponsiveContainer, Legend,
} from 'recharts'

export default function DashboardPage() {
  const user = useAuthStore(s => s.user)
  const navigate = useNavigate()

  const { data: projects, isLoading: pLoad } = useQuery({
    queryKey: ['projects-summary'],
    queryFn: () => projectsApi.list({ page_size: 100 }).then(r => r.data.results || r.data),
  })

  const { data: clients, isLoading: cLoad } = useQuery({
    queryKey: ['clients-summary'],
    queryFn: () => clientsApi.list({ page_size: 100 }).then(r => r.data.results || r.data),
  })

  const projs = projects || []
  const clts = clients || []

  // Derived stats
  const byStatus = {
    planning: projs.filter(p => p.status === 'planning').length,
    in_progress: projs.filter(p => p.status === 'in_progress').length,
    review: projs.filter(p => p.status === 'review').length,
    completed: projs.filter(p => p.status === 'completed').length,
    on_hold: projs.filter(p => p.status === 'on_hold').length,
  }

  const pieData = Object.entries(byStatus).filter(([, v]) => v > 0).map(([k, v]) => ({
    name: STATUS_LABEL[k], value: v, color: STATUS_COLOR[k],
  }))

  const overBudget = projs.filter(p => p.is_over_budget || (p.spent > p.budget && p.budget > 0))
  const highPriority = projs.filter(p => p.priority === 'high' && p.status !== 'completed')
  const avgProgress = projs.length ? Math.round(projs.reduce((a, p) => a + (p.progress || 0), 0) / projs.length) : 0

  const recentProjects = [...projs].sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at)).slice(0, 6)

  // Area chart: mock monthly activity (replace with real data from API)
  const months = ['Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar']
  const areaData = months.map((m, i) => ({
    month: m,
    projects: Math.floor(4 + i * 1.5 + Math.random() * 3),
    completed: Math.floor(2 + i + Math.random() * 2),
  }))

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--sp-8)' }}>
      {/* Greeting */}
      <div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: 800, letterSpacing: '-0.02em' }}>
          Good {getGreeting()}, {user?.name?.split(' ')[0] || 'there'}.
        </h1>
        <p style={{ color: 'var(--text-2)', marginTop: 4, fontSize: '14px' }}>
          Here's what's happening across your workspace.
        </p>
      </div>

      {/* Stat cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 'var(--sp-4)' }}>
        <StatCard label="Total Projects" value={pLoad ? '—' : projs.length} icon={FolderKanban} accent="var(--info)" sub={`${byStatus.in_progress} in progress`} />
        <StatCard label="Clients" value={cLoad ? '—' : clts.length} icon={Building2} accent="var(--accent)" sub={`${clts.filter(c => c.status === 'active').length} active`} />
        <StatCard label="Avg Progress" value={pLoad ? '—' : `${avgProgress}%`} icon={TrendingUp} accent="var(--success)" />
        <StatCard label="Over Budget" value={pLoad ? '—' : overBudget.length} icon={AlertTriangle} accent="var(--danger)" sub={overBudget.length > 0 ? 'Needs attention' : 'All clear'} />
        <StatCard label="High Priority" value={pLoad ? '—' : highPriority.length} icon={Clock} accent="var(--warning)" sub="Active projects" />
        <StatCard label="Completed" value={pLoad ? '—' : byStatus.completed} icon={CheckCircle2} accent="var(--success)" />
      </div>

      {/* Charts row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 'var(--sp-6)' }}>
        {/* Area chart */}
        <div style={{ background: 'var(--bg-1)', border: '1px solid var(--border)', borderRadius: 'var(--r-lg)', padding: 'var(--sp-6)' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: 'var(--sp-5)', fontSize: '1rem' }}>Project Activity</h3>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={areaData}>
              <defs>
                <linearGradient id="gProjects" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#60a5fa" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#60a5fa" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gCompleted" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4ade80" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#4ade80" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" tick={{ fill: 'var(--text-3)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'var(--text-3)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: 'var(--bg-2)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 }} />
              <Area type="monotone" dataKey="projects" stroke="#60a5fa" fill="url(#gProjects)" strokeWidth={2} name="Active" />
              <Area type="monotone" dataKey="completed" stroke="#4ade80" fill="url(#gCompleted)" strokeWidth={2} name="Completed" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Pie chart */}
        <div style={{ background: 'var(--bg-1)', border: '1px solid var(--border)', borderRadius: 'var(--r-lg)', padding: 'var(--sp-6)' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: 'var(--sp-5)', fontSize: '1rem' }}>By Status</h3>
          {pLoad ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[80, 60, 50, 70, 40].map((w, i) => <Skeleton key={i} width={`${w}%`} height={14} />)}
            </div>
          ) : pieData.length === 0 ? (
            <p style={{ color: 'var(--text-3)', fontSize: '13px', textAlign: 'center', marginTop: 40 }}>No project data</p>
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" paddingAngle={2}>
                  {pieData.map((entry, i) => <Cell key={i} fill={entry.color} stroke="transparent" />)}
                </Pie>
                <Tooltip contentStyle={{ background: 'var(--bg-2)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          )}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
            {pieData.map(d => (
              <div key={d.name} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: '12px', color: 'var(--text-2)' }}>
                <div style={{ width: 8, height: 8, borderRadius: 2, background: d.color, flexShrink: 0 }} />
                <span style={{ flex: 1 }}>{d.name}</span>
                <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-1)', fontWeight: 500 }}>{d.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent projects */}
      <div style={{ background: 'var(--bg-1)', border: '1px solid var(--border)', borderRadius: 'var(--r-lg)', padding: 'var(--sp-6)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--sp-5)' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1rem' }}>Recent Projects</h3>
          <button onClick={() => navigate('/projects')} style={{
            background: 'none', border: '1px solid var(--border)', color: 'var(--text-2)',
            borderRadius: 'var(--r-md)', padding: '5px 12px', fontSize: '12px', cursor: 'pointer',
            transition: 'all var(--t-fast)',
          }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.color = 'var(--accent)' }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.color = 'var(--text-2)' }}
          >
            View all →
          </button>
        </div>

        {pLoad ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {[1,2,3].map(i => <Skeleton key={i} height={60} />)}
          </div>
        ) : recentProjects.length === 0 ? (
          <p style={{ color: 'var(--text-3)', textAlign: 'center', padding: 'var(--sp-8)', fontSize: '14px' }}>No projects yet</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            {recentProjects.map((p, i) => (
              <div
                key={p.id}
                onClick={() => navigate(`/projects/${p.id}`)}
                style={{
                  display: 'grid', gridTemplateColumns: '1fr 100px 120px 80px',
                  gap: 'var(--sp-4)', alignItems: 'center',
                  padding: '12px 0', cursor: 'pointer',
                  borderBottom: i < recentProjects.length - 1 ? '1px solid var(--border)' : 'none',
                  transition: 'background var(--t-fast)',
                }}
                onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-2)'}
                onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
              >
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontWeight: 600, fontSize: '13px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</div>
                  <div style={{ fontSize: '11px', color: 'var(--text-3)', marginTop: 2 }}>{p.client?.name || '—'}</div>
                </div>
                <Badge color={STATUS_COLOR[p.status]}>{STATUS_LABEL[p.status] || p.status}</Badge>
                <ProgressBar value={p.progress || 0} showLabel />
                <div style={{ fontSize: '11px', color: 'var(--text-3)', fontFamily: 'var(--font-mono)' }}>
                  {timeAgo(p.updated_at)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function getGreeting() {
  const h = new Date().getHours()
  if (h < 12) return 'morning'
  if (h < 17) return 'afternoon'
  return 'evening'
}
