"""resources/views.py"""
import logging
from django.utils import timezone
from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend

from .models import ResourceProfile, TimeEntry
from .serializers import ResourceProfileSerializer, TimeEntrySerializer
from accounts.permissions import IsAdminOrManager
from accounts.models import User

logger = logging.getLogger('nexus')


class ResourceProfileViewSet(viewsets.ModelViewSet):
    queryset = ResourceProfile.objects.select_related('user').all()
    serializer_class   = ResourceProfileSerializer
    filter_backends    = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields      = ['user__name', 'job_title']
    ordering_fields    = ['user__name', 'hourly_rate', 'availability']

    def get_permissions(self):
        if self.action in ('create', 'update', 'partial_update', 'destroy'):
            return [IsAdminOrManager()]
        return [IsAuthenticated()]

    @action(detail=True, methods=['get'])
    def time_entries(self, request, pk=None):
        profile = self.get_object()
        entries = profile.timeentries.select_related('project').order_by('-date')
        return Response(TimeEntrySerializer(entries, many=True).data)

    @action(detail=True, methods=['patch'], permission_classes=[IsAdminOrManager])
    def set_availability(self, request, pk=None):
        profile = self.get_object()
        try:
            value = int(request.data.get('availability', -1))
            assert 0 <= value <= 100
        except (TypeError, ValueError, AssertionError):
            return Response({'detail': 'availability must be an integer 0–100.'}, status=status.HTTP_400_BAD_REQUEST)
        profile.availability = value
        profile.save(update_fields=['availability', 'updated_at'])
        return Response({'availability': profile.availability})


class TimeEntryViewSet(viewsets.ModelViewSet):
    queryset = TimeEntry.objects.select_related('resource__user', 'project', 'approved_by')
    serializer_class   = TimeEntrySerializer
    permission_classes = [IsAuthenticated]
    filter_backends    = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields   = ['resource', 'project', 'date', 'approved']
    ordering_fields    = ['date', 'hours']

    def get_queryset(self):
        user = self.request.user
        qs   = super().get_queryset()
        if user.role in (User.Role.ADMIN, User.Role.MANAGER):
            return qs
        try:
            return qs.filter(resource=user.resource_profile)
        except ResourceProfile.DoesNotExist:
            return qs.none()

    @action(detail=True, methods=['patch'], permission_classes=[IsAdminOrManager])
    def approve(self, request, pk=None):
        entry = self.get_object()
        if entry.approved:
            return Response({'detail': 'Already approved.'}, status=status.HTTP_400_BAD_REQUEST)
        entry.approved    = True
        entry.approved_by = request.user
        entry.approved_at = timezone.now()
        entry.save(update_fields=['approved', 'approved_by', 'approved_at'])
        return Response({'approved': True, 'approved_by': request.user.name})
