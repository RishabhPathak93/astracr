"""timelines/views.py"""
import logging
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters
from django.utils import timezone

from .models import Timeline, TimelineMilestone
from .serializers import TimelineSerializer, TimelineMilestoneSerializer
from accounts.permissions import IsAdminOrManagerOrReadOnly
from notifications.utils import notify_project_team

logger = logging.getLogger('nexus')


class TimelineViewSet(viewsets.ModelViewSet):
    queryset = Timeline.objects.select_related('project').prefetch_related('assignees', 'milestones')
    serializer_class   = TimelineSerializer
    permission_classes = [IsAdminOrManagerOrReadOnly]
    filter_backends    = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields   = ['project', 'status']
    search_fields      = ['name', 'description']
    ordering_fields    = ['order', 'start_date', 'end_date', 'progress']

    def perform_update(self, serializer):
        old = self.get_object()
        tl  = serializer.save()
        if old.status != tl.status and tl.status == Timeline.Status.COMPLETED:
            notify_project_team(
                users=list(tl.assignees.all()),
                notif_type='timeline_complete',
                title='Phase completed',
                message=f'"{tl.name}" in "{tl.project.name}" is now complete.',
                project=tl.project,
                exclude=self.request.user,
            )

    @action(detail=True, methods=['patch'])
    def update_progress(self, request, pk=None):
        tl  = self.get_object()
        raw = request.data.get('progress')
        try:
            value = int(raw)
            assert 0 <= value <= 100
        except (TypeError, ValueError, AssertionError):
            return Response({'detail': 'progress must be an integer 0–100.'}, status=status.HTTP_400_BAD_REQUEST)
        tl.progress = value
        if value == 100:
            tl.status = Timeline.Status.COMPLETED
        elif value > 0:
            tl.status = Timeline.Status.IN_PROGRESS
        tl.save(update_fields=['progress', 'status', 'updated_at'])
        return Response({'progress': tl.progress, 'status': tl.status})

    @action(detail=True, methods=['post'])
    def add_milestone(self, request, pk=None):
        tl = self.get_object()
        s  = TimelineMilestoneSerializer(data={**request.data, 'timeline': tl.id})
        s.is_valid(raise_exception=True)
        s.save(timeline=tl)
        return Response(s.data, status=status.HTTP_201_CREATED)


class MilestoneViewSet(viewsets.ModelViewSet):
    queryset           = TimelineMilestone.objects.select_related('timeline__project')
    serializer_class   = TimelineMilestoneSerializer
    permission_classes = [IsAdminOrManagerOrReadOnly]
    filter_backends    = [DjangoFilterBackend]
    filterset_fields   = ['timeline', 'completed']

    @action(detail=True, methods=['patch'])
    def complete(self, request, pk=None):
        m = self.get_object()
        m.completed    = True
        m.completed_at = timezone.now()
        m.save(update_fields=['completed', 'completed_at'])
        return Response(TimelineMilestoneSerializer(m).data)
