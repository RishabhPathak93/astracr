"""projects/views.py"""
import logging
from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import Q

from .models import Project, ProjectUpdate, ProjectDocument
from .serializers import (
    ProjectListSerializer, ProjectDetailSerializer,
    ProjectUpdateSerializer, ProjectDocumentSerializer,
)
from accounts.permissions import IsAdminOrManager, IsAdminOrManagerOrReadOnly
from accounts.models import User
from notifications.utils import notify_project_team

logger = logging.getLogger('nexus')


class ProjectViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields   = ['status', 'priority', 'client', 'manager']
    search_fields      = ['name', 'description']
    ordering_fields    = ['name', 'created_at', 'end_date', 'priority', 'progress', 'budget']

    def get_queryset(self):
        user = self.request.user
        base = (
            Project.objects
            .select_related('client', 'manager', 'created_by')
            .prefetch_related('resources', 'updates', 'documents')
        )
        if user.role == User.Role.ADMIN:
            return base.all()
        if user.role == User.Role.MANAGER:
            return base.filter(Q(manager=user) | Q(resources=user)).distinct()
        if user.role == User.Role.RESOURCE:
            return base.filter(resources=user)
        if user.role == User.Role.CLIENT:
            try:
                return base.filter(client=user.client_profile)
            except Exception:
                return base.none()
        return base.none()

    def get_serializer_class(self):
        return ProjectListSerializer if self.action == 'list' else ProjectDetailSerializer

    def get_permissions(self):
        if self.action in ('create', 'update', 'partial_update', 'destroy'):
            return [IsAdminOrManager()]
        return [IsAuthenticated()]

    def get_serializer_context(self):
        ctx = super().get_serializer_context()
        ctx['request'] = self.request
        return ctx

    def perform_create(self, serializer):
        project = serializer.save(created_by=self.request.user)
        logger.info('Project "%s" created by %s', project.name, self.request.user.email)
        for resource in project.resources.all():
            notify_project_team(
                users=[resource],
                notif_type='project_assigned',
                title='You have been assigned to a project',
                message=f'You are now on "{project.name}".',
                project=project,
            )

    def perform_update(self, serializer):
        old_status = self.get_object().status
        project    = serializer.save()
        if old_status != project.status:
            recipients = list(project.resources.all())
            if project.manager:
                recipients.append(project.manager)
            notify_project_team(
                users=recipients,
                notif_type='status_change',
                title='Project status changed',
                message=f'"{project.name}" is now {project.get_status_display()}.',
                project=project,
                exclude=self.request.user,
            )

    def perform_destroy(self, instance):
        name = instance.name
        instance.delete()
        logger.warning('Project "%s" deleted by %s', name, self.request.user.email)

    # ── Custom actions ────────────────────────────────────────────────────────

    @action(detail=True, methods=['post'], permission_classes=[IsAdminOrManager])
    def add_update(self, request, pk=None):
        project    = self.get_object()
        serializer = ProjectUpdateSerializer(data={**request.data, 'project': project.id})
        serializer.is_valid(raise_exception=True)
        serializer.save(author=request.user, project=project)
        notify_project_team(
            users=list(project.resources.all()),
            notif_type='update',
            title='Project update posted',
            message=f'New update on "{project.name}".',
            project=project,
            exclude=request.user,
        )
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['post'], permission_classes=[IsAdminOrManager])
    def upload_document(self, request, pk=None):
        project    = self.get_object()
        serializer = ProjectDocumentSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save(uploaded_by=request.user, project=project)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['patch'], permission_classes=[IsAdminOrManager])
    def update_progress(self, request, pk=None):
        project  = self.get_object()
        raw      = request.data.get('progress')
        if raw is None:
            return Response({'detail': 'progress is required.'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            value = int(raw)
            if not (0 <= value <= 100):
                raise ValueError
        except (ValueError, TypeError):
            return Response({'detail': 'progress must be an integer 0–100.'}, status=status.HTTP_400_BAD_REQUEST)
        project.progress = value
        project.save(update_fields=['progress', 'updated_at'])
        return Response({'id': project.id, 'progress': project.progress})

    @action(detail=True, methods=['post'], permission_classes=[IsAdminOrManager])
    def assign_resource(self, request, pk=None):
        project = self.get_object()
        try:
            user = User.objects.get(pk=request.data.get('user_id'), role=User.Role.RESOURCE, is_active=True)
        except User.DoesNotExist:
            return Response({'detail': 'Active resource user not found.'}, status=status.HTTP_404_NOT_FOUND)
        project.resources.add(user)
        notify_project_team(users=[user], notif_type='project_assigned',
                            title='Added to project', message=f'You have been added to "{project.name}".', project=project)
        return Response({'detail': f'{user.name} added to project.'})

    @action(detail=True, methods=['post'], permission_classes=[IsAdminOrManager])
    def remove_resource(self, request, pk=None):
        project = self.get_object()
        try:
            user = User.objects.get(pk=request.data.get('user_id'))
        except User.DoesNotExist:
            return Response({'detail': 'User not found.'}, status=status.HTTP_404_NOT_FOUND)
        project.resources.remove(user)
        return Response({'detail': f'{user.name} removed from project.'})
