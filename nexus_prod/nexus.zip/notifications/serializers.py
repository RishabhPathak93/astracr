"""notifications/serializers.py"""
from rest_framework import serializers
from .models import Notification


class NotificationSerializer(serializers.ModelSerializer):
    project_name = serializers.CharField(source='project.name', read_only=True)

    class Meta:
        model  = Notification
        fields = ['id', 'notif_type', 'title', 'message', 'is_read',
                  'project', 'project_name', 'action_url', 'created_at']
        read_only_fields = ['id', 'created_at']
