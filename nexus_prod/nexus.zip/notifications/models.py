"""notifications/models.py"""
from django.db import models
from accounts.models import User


class Notification(models.Model):
    class Type(models.TextChoices):
        PROJECT_ASSIGNED  = 'project_assigned',  'Project Assigned'
        STATUS_CHANGE     = 'status_change',      'Status Change'
        DEADLINE          = 'deadline',            'Deadline'
        TIMELINE_COMPLETE = 'timeline_complete',   'Timeline Complete'
        MESSAGE           = 'message',             'New Message'
        UPDATE            = 'update',              'Project Update'
        MENTION           = 'mention',             'Mention'

    user       = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications', db_index=True)
    notif_type = models.CharField(max_length=30, choices=Type.choices)
    title      = models.CharField(max_length=200)
    message    = models.TextField()
    is_read    = models.BooleanField(default=False, db_index=True)
    project    = models.ForeignKey(
        'projects.Project', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='notifications'
    )
    action_url = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        indexes  = [models.Index(fields=['user', 'is_read'])]

    def __str__(self):
        return f'[{self.notif_type}] {self.user} — {self.title}'
