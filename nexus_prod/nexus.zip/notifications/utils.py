"""notifications/utils.py"""
import logging
from typing import Iterable, Optional
from accounts.models import User

logger = logging.getLogger('nexus')


def notify_project_team(
    users: Iterable,
    notif_type: str,
    title: str,
    message: str,
    project=None,
    action_url: str = '',
    exclude: Optional[User] = None,
) -> int:
    """
    Bulk-create notifications for a list of users.
    Returns the count created.
    """
    from .models import Notification
    to_create = [
        Notification(
            user=u,
            notif_type=notif_type,
            title=title,
            message=message,
            project=project,
            action_url=action_url,
        )
        for u in users
        if u and u.is_active and u != exclude
    ]
    if to_create:
        Notification.objects.bulk_create(to_create, ignore_conflicts=True)
    return len(to_create)


def notify_user(user: User, notif_type: str, title: str, message: str, project=None, action_url: str = ''):
    """Single-user shortcut."""
    return notify_project_team([user], notif_type, title, message, project, action_url)
